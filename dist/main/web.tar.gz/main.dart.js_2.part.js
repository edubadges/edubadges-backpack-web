((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
aGW(d,e,f){return new B.uj(d,f,e,null)},
uj:function uj(d,e,f,g){var _=this
_.d=d
_.e=e
_.f=f
_.a=g},
Ss:function Ss(d){var _=this
_.w=d
_.d=$
_.c=_.a=null},
b4j:function b4j(d){this.a=d},
b4k:function b4k(d,e){this.a=d
this.b=e},
b4i:function b4i(){},
b4m:function b4m(d){this.a=d},
b4l:function b4l(){}},D
A=c[0]
C=c[2]
B=a.updateHolder(c[4],B)
D=c[7]
B.uj.prototype={
ag(){return new B.Ss(A.kc(null,null))}}
B.Ss.prototype={
m(){this.w.m()
this.aB()},
aEs(d){var x=d.ay,w=d.CW,v=A.b([],y.h)
if(x!=null&&x.length!==0)v.push(x)
if(w!=null&&w.length!==0)v.push(w)
if(v.length===0)return null
return C.b.b6(v,"\n\n")},
aEr(){var x,w=this,v=w.a
if(v.f){v=w.c
v.toString
A.h8(v,!1).dk()}else{v=w.c
v.toString
v=A.co(v).c
v===$&&A.a()
v=v.jh()
x=w.c
if(v){x.toString
A.co(x).hz(null)}else{x.toString
A.co(x).fG("/catalog",null)}}},
J(d){var x,w,v,u,t,s,r,q,p,o,n=this,m=null,l=A.aL(d,C.x,y.p)
l.toString
x=A.K(d).ax
w=n.gbw()
v=$.vQ()
u=n.a
t=w.ce(v.$1(new A.nO(u.e,u.d)),y.a)
u=A.Az(t,y.k)
if(u==null)s=m
else{w=u.b.a
s=w==null?m:w.b.ch}w=n.a.f?m:new A.w1(n.ga3i(),"/",m)
v=A.ah(l.gUq(),m,m,m,m,m,m,m)
u=x.p4
r=u==null
q=r?x.k2:u
p=r?x.k2:u
o=A.b([],y.e)
if(n.a.f)o.push(A.iF(m,m,A.eL(C.em,x.b,m,m),m,m,n.ga3i(),m,m,l.gvh()))
if(s!=null&&s.length!==0)o.push(A.iF(m,m,A.eL(D.Af,x.k3,m,m),m,m,new B.b4j(s),m,m,m))
w=A.jH(o,!1,q,m,w,p,v,m)
v=r?x.k2:u
return A.ep(w,v,A.jg(A.fi(t,new B.b4k(n,d),new B.b4l(),new B.b4m(l),!1,!0,!1),!0,720,n.w),m)}}
var z=a.updateTypes(["~()"])
B.b4j.prototype={
$0(){return A.A8(this.a)},
$S:0}
B.b4k.prototype={
$1(d){var x=null,w=d==null?x:d.b,v=w!=null?this.a.aEs(w):x,u=v==null?x:C.c.bd(v)
if(u==null)u=""
if(u.length===0)return D.Yi
return A.nd(new A.iD(A.tY(A.vG(u),new B.b4i(),A.w3(this.b)),x),this.a.w,C.Z,C.zw,x,x,C.ax)},
$S:1066}
B.b4i.prototype={
$3(d,e,f){if(e==null)return
A.A8(e)},
$S:1067}
B.b4m.prototype={
$0(){var x=null
return A.ba(A.e_(x,x,x,this.a.gdQ(),x,x,x,x,x,x),x,x)},
$S:39}
B.b4l.prototype={
$2(d,e){return A.ba(A.nY(d,e),null,null)},
$S:46};(function installTearOffs(){var x=a._instance_0u
x(B.Ss.prototype,"ga3i","aEr",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.uj,A.px)
x(B.Ss,A.tc)
w(A.wq,[B.b4j,B.b4m])
w(A.mD,[B.b4k,B.b4i])
x(B.b4l,A.wr)})()
A.b8l(b.typeUniverse,JSON.parse('{"uj":{"Y":[],"f":[]},"Ss":{"a0":["uj"]}}'))
var y={p:A.a5("kC"),a:A.a5("bc<h1?>"),h:A.a5("y<c>"),e:A.a5("y<f>"),k:A.a5("h1?")};(function constants(){D.Yi=new A.iy(C.ag,null,null,C.zI,null)
D.Af=new A.fq(58220,"MaterialIcons",null,!0)})()};
(a=>{a["WL4drNJxzHSU3BDM47XxV7AhzAw="]=a.current})($__dart_deferred_initializers__);