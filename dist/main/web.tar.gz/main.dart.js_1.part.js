((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={Xg:function Xg(d){this.a=d
this.c=this.b=null},C6:function C6(d){this.a=d},
bCj(d){return new B.tw(d,null)},
tw:function tw(d,e){this.d=d
this.a=e},
Rk:function Rk(d){var _=this
_.w=d
_.x=!1
_.d=$
_.c=_.a=null},
b1f:function b1f(d){this.a=d},
b1g:function b1g(d){this.a=d},
b1h:function b1h(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
b1j:function b1j(d){this.a=d},
b1i:function b1i(){},
bcJ:function bcJ(){},
bdt:function bdt(){}},D
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[3],B)
D=c[8]
B.Xg.prototype={
gGw(){return this.b},
gadZ(){return this.b!=null},
gKf(){return this.a.a},
a8M(d){var x,w=this,v=null,u=w.a
if((u.a.a&30)!==0){u=w.b
if(!J.d(d,u==null?v:u.d)){u=w.b
A.j(u==null?v:u.d)
A.j(d)
u=w.b
A.j(u==null?v:u.e)
A.dF().j(0)
A.dF()}return}x=w.c
if(x==null)x=A.boM(v,v,v,v,v,v,v,v,v,v,v,v,v,"",v,v,v,v,v,v,v,v,v,v,v)
x=A.ti(d,"The request was manually cancelled by the user.",x,v,A.dF(),C.kT)
w.b=x
u.cL(x)},
b4(){return this.a8M(null)}}
B.C6.prototype={
FN(){var x=0,w=A.t(y.v),v=1,u=[],t=this,s,r,q,p,o,n
var $async$FN=A.o(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:v=3
x=6
return A.n(t.a.l7("/accept-general-terms",y.v),$async$FN)
case 6:s=e
if(s.c!==200){p=A.cT("Failed to accept general terms")
throw A.h(p)}v=1
x=5
break
case 3:v=2
n=u.pop()
r=A.Z(n)
q=A.ac(n)
$.cY().kP("Error accepting general terms",r,q)
throw n
x=5
break
case 2:x=1
break
case 5:return A.q(null,w)
case 1:return A.p(u.at(-1),w)}})
return A.r($async$FN,w)},
$ibmx:1}
B.tw.prototype={
ag(){return new B.Rk(A.kc(null,null))}}
B.Rk.prototype={
aA(){this.aY()
this.w.a4(this.ga4g())},
m(){var x=this.w
x.N(this.ga4g())
x.m()
this.aB()},
aFU(){var x=this,w=x.w.f,v=C.b.gbB(w).at
v.toString
w=C.b.gbB(w).Q
w.toString
if(v>=w-100){if(!x.x)x.a_(new B.b1f(x))}else if(x.x)x.a_(new B.b1g(x))},
aFW(){var x=this.w,w=C.b.gbB(x.f).Q
w.toString
x.kJ(w,C.tp,C.el)},
yL(){var x=0,w=A.t(y.v),v=this,u,t
var $async$yL=A.o(function(d,e){if(d===1)return A.p(e,w)
for(;;)switch(x){case 0:t=v.gbw()
x=2
return A.n(t.ce($.byb(),y.l).FN(),$async$yL)
case 2:x=3
return A.n(t.au($.beP().gn9(),y.D),$async$yL)
case 3:u=e
t=v.c
if(t!=null)if(u)A.co(t).fG("/notification-permission",null)
else A.co(t).fG("/",null)
return A.q(null,w)}})
return A.r($async$yL,w)},
J(d){var x,w,v,u,t=this,s=null,r=A.aL(d,C.x,y.F)
r.toString
x=A.K(d)
w=t.gbw().ce($.byi().$1(t.a.d),y.p)
v=t.x?r.gVu():r.gVv()
u=t.x?t.gapV():t.gaFV()
return A.ep(A.jH(s,!1,s,!0,s,s,A.ah(r.gVw(),s,s,s,s,s,s,s),s),s,A.jg(A.kh(C.cf,A.b([A.fi(w,new B.b1h(t,d,x,x.ok,x.ax),new B.b1i(),new B.b1j(d),!1,!0,!1),A.Dy(0,A.dg(s,new A.yk(v,u,!1,s),C.B,A.K(d).fx,s,s,s,s,s,D.a2p,s,s,s),s,s,0,0,s,s)],y.u),C.P,C.c9,s),!0,720,t.w),s)}}
var z=a.updateTypes(["~()","~([i?])","Q<~>()","C6(b0)"])
B.b1f.prototype={
$0(){this.a.x=!0},
$S:0}
B.b1g.prototype={
$0(){this.a.x=!1},
$S:0}
B.b1h.prototype={
$1(d){var x,w,v,u=this,t=null
if(d.length===0){x=A.aL(u.b,C.x,y.F)
x.toString
return A.ba(A.e_(t,t,t,x.gdQ(),t,t,t,t,t,t),t,t)}x=A.vG(d)
w=A.bnw(u.c)
v=u.d.z
return A.nd(new A.iD(A.tY(x,t,w.aM9(v==null?t:v.aU(u.e.k3))),t),u.a.w,C.Z,D.a2q,t,t,C.ax)},
$S:1058}
B.b1j.prototype={
$0(){var x=null,w=A.aL(this.a,C.x,y.F)
w.toString
return A.ba(A.e_(x,x,x,w.gdQ(),x,x,x,x,x,x),x,x)},
$S:39}
B.b1i.prototype={
$2(d,e){return A.ba(A.nY(d,e),null,null)},
$S:46}
B.bcJ.prototype={
$1(d){return new B.C6(d.ce($.ml(),y.o))},
$S:z+3}
B.bdt.prototype={
$2(d,e){return this.air(d,e)},
air(d,e){var x=0,w=A.t(y.w),v,u,t,s,r,q
var $async$$2=A.o(function(f,g){if(f===1)return A.p(g,w)
for(;;)switch(x){case 0:if(A.bjc(e)!=="https")throw A.h(A.cT("Refusing to load terms content over a non-https URL."))
u=A.a_m(A.apc(D.a1y,!0,D.adv,3,C.dQ,C.vO,null))
t=new B.Xg(new A.bf(new A.ae($.ab,y.q),y.B))
d.TU(t.gji())
x=3
return A.n(u.aiz(e,t,y.w),$async$$2)
case 3:s=g
r=s.a
q=s.c
if(q!==200||r==null)throw A.h(A.cT("Failed to load terms content from "+e+". Status: "+A.j(q)))
if(r.length>2097152)throw A.h(A.cT("Terms content from "+e+" exceeds the size limit."))
v=r
x=1
break
case 1:return A.q(v,w)}})
return A.r($async$$2,w)},
$S:334};(function installTearOffs(){var x=a.installInstanceTearOff,w=a._instance_0u
x(B.Xg.prototype,"gji",0,0,function(){return[null]},["$1","$0"],["a8M","b4"],1,0,0)
var v
w(v=B.Rk.prototype,"ga4g","aFU",0)
w(v,"gaFV","aFW",0)
w(v,"gapV","yL",2)})();(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.i,[B.Xg,B.C6])
w(B.tw,A.px)
w(B.Rk,A.tc)
x(A.wq,[B.b1f,B.b1g,B.b1j])
x(A.mD,[B.b1h,B.bcJ])
x(A.wr,[B.b1i,B.bdt])})()
A.b8l(b.typeUniverse,JSON.parse('{"C6":{"bmx":[]},"tw":{"Y":[],"f":[]},"Rk":{"a0":["tw"]}}'))
var y=(function rtii(){var x=A.a5
return{o:x("w0"),F:x("kC"),p:x("bc<c>"),D:x("Q<w>"),l:x("bmx"),u:x("y<f>"),w:x("c"),B:x("bf<e6>"),q:x("ae<e6>"),v:x("~")}})();(function constants(){D.a1y=new A.aW(15e6)
D.a2p=new A.ai(24,12,24,24)
D.a2q=new A.ai(24,16,24,120)
D.aev={Accept:0}
D.adv=new A.P(D.aev,["text/markdown, text/plain"],A.a5("P<c,c>"))})();(function lazyInitializers(){var x=a.lazyFinal
x($,"bYD","byb",()=>A.eb(new B.bcJ(),null,!1,null,null,y.l))
x($,"bZ3","byi",()=>{var w=y.w
return C.dL.AX(new B.bdt(),w,w)})})()};
(a=>{a["AZGFG7ULOesF1IR7/bDsgQkJrK4="]=a.current})($__dart_deferred_initializers__);