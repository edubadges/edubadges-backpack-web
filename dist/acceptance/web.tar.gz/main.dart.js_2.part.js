((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
aIh(d,e,f){return new B.uI(d,f,e,null)},
uI:function uI(d,e,f,g){var _=this
_.d=d
_.e=e
_.f=f
_.a=g},
Td:function Td(d){var _=this
_.w=d
_.d=$
_.c=_.a=null},
b67:function b67(d){this.a=d},
b68:function b68(d,e){this.a=d
this.b=e},
b66:function b66(){},
b6a:function b6a(){},
b69:function b69(){}},D
A=c[0]
C=c[2]
B=a.updateHolder(c[4],B)
D=c[7]
B.uI.prototype={
a8(){return new B.Td(A.js(null,null))}}
B.Td.prototype={
m(){this.w.m()
this.aw()},
aG0(d){var x=d.ay,w=d.CW,v=A.b([],y.h)
if(x!=null&&x.length!==0)v.push(x)
if(w!=null&&w.length!==0)v.push(w)
if(v.length===0)return null
return C.b.b6(v,"\n\n")},
aG_(){var x,w=this,v=w.a
if(v.f){v=w.c
v.toString
A.iP(v,!1).dS()}else{v=w.c
v.toString
v=A.d1(v).c
v===$&&A.a()
v=v.k6()
x=w.c
if(v){x.toString
A.d1(x).jF(null)}else{x.toString
A.d1(x).hm("/catalog",null)}}},
I(d){var x,w,v,u,t,s,r,q,p,o,n=this,m=null,l=A.b1(d,C.D,y.p)
l.toString
x=A.H(d).ax
w=n.gbu()
v=$.nW()
u=n.a
t=w.bA(v.$1(new A.mF(u.e,u.d)),y.a)
u=A.pt(t,y.k)
if(u==null)s=m
else{w=u.b.a
s=w==null?m:w.b.ch}w=n.a.f
v=w?m:new A.wk(n.ga4f(),"/",m)
w=w?m:1
w=A.aG(m,m,A.an(l.gxS(),m,m,m,m,m,m,m),!1,m,m,!1,!1,m,m,m,w,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,C.p,m)
u=x.p4
r=u==null
q=r?x.k2:u
p=r?x.k2:u
o=A.b([],y.e)
if(n.a.f)o.push(A.il(m,m,A.eR(C.dV,x.b,m,m),m,m,n.ga4f(),m,m,l.gt5()))
if(s!=null&&s.length!==0)o.push(A.il(m,m,A.eR(D.AE,x.k3,m,m),m,m,new B.b67(s),m,m,l.gLA()))
l=A.kI(o,!1,q,m,!1,v,p,w,m)
w=r?x.k2:u
return A.fD(l,w,A.k8(A.fR(t,new B.b68(n,d),new B.b69(),new B.b6a(),!1,!0,!1),!0,720,n.w),m)}}
var z=a.updateTypes(["~()"])
B.b67.prototype={
$0(){return A.At(this.a)},
$S:0}
B.b68.prototype={
$1(d){var x=null,w=d==null?x:d.b,v=w!=null?this.a.aG0(w):x,u=v==null?x:C.c.b5(v)
if(u==null)u=""
if(u.length===0)return C.yM
return A.m7(new A.q9(A.ul(A.w0(u),new B.b66(),A.wl(this.b)),!1,x),this.a.w,C.Z,C.zU,x,x,C.at)},
$S:1091}
B.b66.prototype={
$3(d,e,f){if(e==null)return
A.At(e)},
$S:1092}
B.b6a.prototype={
$0(){return C.be},
$S:51}
B.b69.prototype={
$2(d,e){return A.bT(A.lL(d,e),null,null)},
$S:55};(function installTearOffs(){var x=a._instance_0u
x(B.Td.prototype,"ga4f","aG_",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.uI,A.wJ)
x(B.Td,A.tC)
w(A.wD,[B.b67,B.b6a])
w(A.mN,[B.b68,B.b66])
x(B.b69,A.wE)})()
A.bat(b.typeUniverse,JSON.parse('{"uI":{"X":[],"f":[]},"Td":{"a_":["uI"]}}'))
var y={p:A.a5("je"),a:A.a5("b3<h6?>"),h:A.a5("y<c>"),e:A.a5("y<f>"),k:A.a5("h6?")};(function constants(){D.AE=new A.fy(58220,"MaterialIcons",null,!0)})()};
(a=>{a["wAkBtEZuv7WI+T/UJdPPAqqMBK8="]=a.current})($__dart_deferred_initializers__);