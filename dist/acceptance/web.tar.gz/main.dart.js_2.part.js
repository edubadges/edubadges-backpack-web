((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
aHZ(d,e,f){return new B.uE(d,f,e,null)},
uE:function uE(d,e,f,g){var _=this
_.d=d
_.e=e
_.f=f
_.a=g},
T2:function T2(d){var _=this
_.w=d
_.d=$
_.c=_.a=null},
b5y:function b5y(d){this.a=d},
b5z:function b5z(d,e){this.a=d
this.b=e},
b5x:function b5x(){},
b5B:function b5B(d){this.a=d},
b5A:function b5A(){}},D
A=c[0]
C=c[2]
B=a.updateHolder(c[4],B)
D=c[7]
B.uE.prototype={
ac(){return new B.T2(A.ke(null,null))}}
B.T2.prototype={
m(){this.w.m()
this.aw()},
aFI(d){var x=d.ay,w=d.CW,v=A.b([],y.h)
if(x!=null&&x.length!==0)v.push(x)
if(w!=null&&w.length!==0)v.push(w)
if(v.length===0)return null
return C.b.b5(v,"\n\n")},
aFH(){var x,w=this,v=w.a
if(v.f){v=w.c
v.toString
A.iO(v,!1).dU()}else{v=w.c
v.toString
v=A.cY(v).c
v===$&&A.a()
v=v.k6()
x=w.c
if(v){x.toString
A.cY(x).jF(null)}else{x.toString
A.cY(x).hc("/catalog",null)}}},
J(d){var x,w,v,u,t,s,r,q,p,o,n=this,m=null,l=A.aI(d,C.w,y.p)
l.toString
x=A.I(d).ax
w=n.gbA()
v=$.pl()
u=n.a
t=w.bJ(v.$1(new A.nX(u.e,u.d)),y.a)
u=A.AM(t,y.k)
if(u==null)s=m
else{w=u.b.a
s=w==null?m:w.b.ch}w=n.a.f?m:new A.wh(n.ga46(),"/",m)
v=A.ak(l.gV4(),m,m,m,m,m,m,m)
u=x.p4
r=u==null
q=r?x.k2:u
p=r?x.k2:u
o=A.b([],y.e)
if(n.a.f)o.push(A.ie(m,m,A.eP(C.dU,x.b,m,m),m,m,n.ga46(),m,m,l.gt6()))
if(s!=null&&s.length!==0)o.push(A.ie(m,m,A.eP(D.Ay,x.k3,m,m),m,m,new B.b5y(s),m,m,m))
w=A.kF(o,!1,q,m,w,p,v,m)
v=r?x.k2:u
return A.eF(w,v,A.k5(A.fO(t,new B.b5z(n,d),new B.b5A(),new B.b5B(l),!1,!0,!1),!0,720,n.w),m)}}
var z=a.updateTypes(["~()"])
B.b5y.prototype={
$0(){return A.Ao(this.a)},
$S:0}
B.b5z.prototype={
$1(d){var x=null,w=d==null?x:d.b,v=w!=null?this.a.aFI(w):x,u=v==null?x:C.c.b7(v)
if(u==null)u=""
if(u.length===0)return C.yD
return A.nk(new A.iH(A.ui(A.vW(u),new B.b5x(),A.wi(this.b)),x),this.a.w,C.a_,C.zO,x,x,C.ay)},
$S:1084}
B.b5x.prototype={
$3(d,e,f){if(e==null)return
A.Ao(e)},
$S:1085}
B.b5B.prototype={
$0(){var x=null
return A.bf(A.dR(x,x,x,this.a.gdN(),x,x,x,x,x,x),x,x)},
$S:52}
B.b5A.prototype={
$2(d,e){return A.bf(A.lI(d,e),null,null)},
$S:60};(function installTearOffs(){var x=a._instance_0u
x(B.T2.prototype,"ga46","aFH",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.uE,A.pK)
x(B.T2,A.tB)
w(A.wE,[B.b5y,B.b5B])
w(A.mK,[B.b5z,B.b5x])
x(B.b5A,A.wF)})()
A.b9U(b.typeUniverse,JSON.parse('{"uE":{"X":[],"f":[]},"T2":{"a_":["uE"]}}'))
var y={p:A.a5("kG"),a:A.a5("bc<h4?>"),h:A.a5("y<c>"),e:A.a5("y<f>"),k:A.a5("h4?")};(function constants(){D.Ay=new A.fu(58220,"MaterialIcons",null,!0)})()};
(a=>{a["4KVUgJFOmPam/O5ChX/VeDZYsDA="]=a.current})($__dart_deferred_initializers__);