((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
aGU(d,e,f){return new B.ui(d,f,e,null)},
ui:function ui(d,e,f,g){var _=this
_.d=d
_.e=e
_.f=f
_.a=g},
St:function St(d){var _=this
_.w=d
_.d=$
_.c=_.a=null},
b4h:function b4h(d){this.a=d},
b4i:function b4i(d,e){this.a=d
this.b=e},
b4g:function b4g(){},
b4k:function b4k(d){this.a=d},
b4j:function b4j(){}},D
A=c[0]
C=c[2]
B=a.updateHolder(c[4],B)
D=c[7]
B.ui.prototype={
ag(){return new B.St(A.kc(null,null))}}
B.St.prototype={
m(){this.w.m()
this.aB()},
aEr(d){var x=d.ay,w=d.CW,v=A.b([],y.h)
if(x!=null&&x.length!==0)v.push(x)
if(w!=null&&w.length!==0)v.push(w)
if(v.length===0)return null
return C.b.bc(v,"\n\n")},
aEq(){var x,w=this,v=w.a
if(v.f){v=w.c
v.toString
A.h7(v,!1).dk()}else{v=w.c
v.toString
v=A.co(v).c
v===$&&A.a()
v=v.jg()
x=w.c
if(v){x.toString
A.co(x).hy(null)}else{x.toString
A.co(x).fG("/catalog",null)}}},
J(d){var x,w,v,u,t,s,r,q,p,o,n=this,m=null,l=A.aL(d,C.x,y.p)
l.toString
x=A.K(d).ax
w=n.gbx()
v=$.vP()
u=n.a
t=w.cj(v.$1(new A.nN(u.e,u.d)),y.a)
u=A.Ax(t,y.k)
if(u==null)s=m
else{w=u.b.a
s=w==null?m:w.b.ch}w=n.a.f?m:new A.w0(n.ga3i(),"/",m)
v=A.ah(l.gUq(),m,m,m,m,m,m,m)
u=x.p4
r=u==null
q=r?x.k2:u
p=r?x.k2:u
o=A.b([],y.e)
if(n.a.f)o.push(A.iF(m,m,A.eK(C.em,x.b,m,m),m,m,n.ga3i(),m,m,l.gvg()))
if(s!=null&&s.length!==0)o.push(A.iF(m,m,A.eK(D.Af,x.k3,m,m),m,m,new B.b4h(s),m,m,m))
w=A.jH(o,!1,q,m,w,p,v,m)
v=r?x.k2:u
return A.en(w,v,A.jg(A.fg(t,new B.b4i(n,d),new B.b4j(),new B.b4k(l),!1,!0,!1),!0,720,n.w),m)}}
var z=a.updateTypes(["~()"])
B.b4h.prototype={
$0(){return A.GQ(this.a,C.j9)},
$S:0}
B.b4i.prototype={
$1(d){var x,w=null,v=d==null?w:d.b,u=v!=null?this.a.aEr(v):w,t=u==null?w:C.c.bh(u)
if(t==null)t=""
if(t.length===0)return D.Yh
x=A.aB("^>\\s*$",!0,!0,!1)
return A.nc(new A.iD(A.tX(A.cs(t,x,""),new B.b4g(),A.w2(this.b)),w),this.a.w,C.Z,C.zw,w,w,C.ax)},
$S:1064}
B.b4g.prototype={
$3(d,e,f){if(e==null)return
A.GQ(e,C.j9)},
$S:1065}
B.b4k.prototype={
$0(){var x=null
return A.ba(A.e_(x,x,x,this.a.gdQ(),x,x,x,x,x,x),x,x)},
$S:43}
B.b4j.prototype={
$2(d,e){return A.ba(A.nX(d,e),null,null)},
$S:47};(function installTearOffs(){var x=a._instance_0u
x(B.St.prototype,"ga3i","aEq",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.ui,A.pw)
x(B.St,A.tb)
w(A.wp,[B.b4h,B.b4k])
w(A.mC,[B.b4i,B.b4g])
x(B.b4j,A.wq)})()
A.b8j(b.typeUniverse,JSON.parse('{"ui":{"Y":[],"f":[]},"St":{"a0":["ui"]}}'))
var y={p:A.a5("kB"),a:A.a5("bf<h0?>"),h:A.a5("y<c>"),e:A.a5("y<f>"),k:A.a5("h0?")};(function constants(){D.Yh=new A.iy(C.ag,null,null,C.zI,null)
D.Af=new A.fp(58220,"MaterialIcons",null,!0)})()};
(a=>{a["DKL56RzUNm2LSoOEAD415MWQW5k="]=a.current})($__dart_deferred_initializers__);