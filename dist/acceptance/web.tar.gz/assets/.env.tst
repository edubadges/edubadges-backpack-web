# Configuration for the 'tst' flavor.
#
# WARNING: this file is bundled as a Flutter asset (see pubspec.yaml) and is
# publicly downloadable on web at /assets/.env.tst. Everything in here must
# be safe to publish. Never add a client secret, API key or token to these files
# - the OpenID client is a public PKCE client and has no secret by design.

ENABLE_CRASHLYTICS=true
ENABLE_ANALYTICS=false

API_URL=https://api-demo.edubadges.nl/mobile/api
OPEN_ID_URL=https://connect.test.surfconext.nl/oidc
OPEN_ID_CLIENT_ID=edubadges.mobile.test
PUBLIC_COLLECTION_BASE_URL=https://demo.edubadges.nl/public/collections
PIWIKPRO_BASE_URL=https://surfnl.piwik.pro
PIWIKPRO_SITE_ID=f80ee6ee-c77c-4d03-9e84-7c3fb12e5741
