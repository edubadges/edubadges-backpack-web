((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={Ya:function Ya(d){this.a=d
this.c=this.b=null},Ct:function Ct(d){this.a=d},
bFz(d){return new B.tV(d,null)},
tV:function tV(d,e){this.d=d
this.a=e},
S4:function S4(d){var _=this
_.w=d
_.x=!1
_.d=$
_.c=_.a=null},
b2V:function b2V(d){this.a=d},
b2W:function b2W(d){this.a=d},
b2X:function b2X(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
b2Z:function b2Z(){},
b2Y:function b2Y(){},
bfl:function bfl(){},
bg7:function bg7(){}},D
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[3],B)
D=c[8]
B.Ya.prototype={
gHf(){return this.b},
gafd(){return this.b!=null},
gL4(){return this.a.a},
a9V(d){var x,w=this,v=null,u=w.a
if((u.a.a&30)!==0){u=w.b
if(!J.d(d,u==null?v:u.d)){u=w.b
A.j(u==null?v:u.d)
A.j(d)
u=w.b
A.j(u==null?v:u.e)
A.dZ().j(0)
A.dZ()}return}x=w.c
if(x==null)x=A.bjF(v,v,v,v,v,v,v,v,v,v,v,v,v,"",v,v,v,v,v,v,v,v,v,v,v)
x=A.pU(d,"The request was manually cancelled by the user.",x,v,A.dZ(),C.la)
w.b=x
u.cT(x)},
b3(){return this.a9V(null)}}
B.Ct.prototype={
Gx(){var x=0,w=A.t(y.v),v=1,u=[],t=this,s,r,q,p,o,n
var $async$Gx=A.o(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:v=3
x=6
return A.m(t.a.le("/accept-general-terms",y.v),$async$Gx)
case 6:s=e
if(s.c!==200){p=A.cW("Failed to accept general terms")
throw A.h(p)}v=1
x=5
break
case 3:v=2
n=u.pop()
r=A.Z(n)
q=A.aa(n)
$.cq().kb("Error accepting general terms",r,q)
throw n
x=5
break
case 2:x=1
break
case 5:return A.q(null,w)
case 1:return A.p(u.at(-1),w)}})
return A.r($async$Gx,w)},
$ibpx:1}
B.tV.prototype={
a8(){return new B.S4(A.js(null,null))}}
B.S4.prototype={
az(){this.aV()
this.w.a5(this.ga5k())},
m(){var x=this.w
x.N(this.ga5k())
x.m()
this.aw()},
aHB(){var x=this,w=x.w.f,v=C.b.gbD(w).at
v.toString
w=C.b.gbD(w).Q
w.toString
if(v>=w-100){if(!x.x)x.X(new B.b2V(x))}else if(x.x)x.X(new B.b2W(x))},
aHD(){var x=this.w,w=C.b.gbD(x.f).Q
w.toString
x.k5(w,C.tH,C.ep)},
z5(){var x=0,w=A.t(y.v),v=this,u,t
var $async$z5=A.o(function(d,e){if(d===1)return A.p(e,w)
for(;;)switch(x){case 0:t=v.gbu()
x=2
return A.m(t.bA($.bBh(),y.l).Gx(),$async$z5)
case 2:t.uD($.WV())
x=3
return A.m(t.an($.bhw().glp(),y.D),$async$z5)
case 3:u=e
t=v.c
if(t!=null)if(u)A.d1(t).hm("/notification-permission",null)
else A.d1(t).hm("/",null)
return A.q(null,w)}})
return A.r($async$z5,w)},
I(d){var x,w,v,u,t=this,s=null,r=A.b1(d,C.D,y.F)
r.toString
x=A.H(d)
w=t.gbu().bA($.bBp().$1(t.a.d),y.p)
v=t.x?r.gWi():r.gWj()
u=t.x?t.garh():t.gaHC()
return A.fD(A.kI(s,!1,s,!0,!1,s,s,A.aG(s,s,A.an(r.gL7(),s,s,s,s,s,s,s),!1,s,s,!1,!1,s,s,s,1,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,C.p,s),s),s,A.k8(A.iZ(C.bP,A.b([A.fR(w,new B.b2X(t,x,x.ok,x.ax),new B.b2Y(),new B.b2Z(),!1,!0,!1),A.yx(0,A.dN(s,new A.uF(v,u,!1,s),C.E,A.H(d).fx,s,s,s,s,s,D.a2T,s,s,s),s,s,0,0,s,s)],y.u),C.P,C.bM,s),!0,720,t.w),s)}}
var z=a.updateTypes(["~()","~([i?])","P<~>()","Ct(aS)"])
B.b2V.prototype={
$0(){this.a.x=!0},
$S:0}
B.b2W.prototype={
$0(){this.a.x=!1},
$S:0}
B.b2X.prototype={
$1(d){var x,w,v,u,t,s=this,r=null
if(d.length===0)return C.be
x=A.w0(d)
w=A.bqx(s.b)
v=s.c.z
u=v==null
t=u?r:v.aS(s.d.k3)
return A.m7(new A.q9(A.ul(x,r,w.aOe(u?r:v.AY(s.d.b,C.cW),t)),!1,r),s.a.w,C.Z,D.a2U,r,r,C.at)},
$S:1083}
B.b2Z.prototype={
$0(){return C.be},
$S:51}
B.b2Y.prototype={
$2(d,e){return A.bT(A.lL(d,e),null,null)},
$S:55}
B.bfl.prototype={
$1(d){return new B.Ct(d.bA($.mv(),y.o))},
$S:z+3}
B.bg7.prototype={
$2(d,e){return this.ajJ(d,e)},
ajJ(d,e){var x=0,w=A.t(y.w),v,u,t,s,r,q
var $async$$2=A.o(function(f,g){if(f===1)return A.p(g,w)
for(;;)switch(x){case 0:if(A.bm3(e)!=="https")throw A.h(A.cW("Refusing to load terms content over a non-https URL."))
u=A.a0e(A.aqo(D.a20,!0,D.ae7,3,C.dU,C.w6,null))
t=new B.Ya(new A.bh(new A.af($.ac,y.q),y.B))
d.JB(t.ghu())
x=3
return A.m(u.ajR(e,t,y.w),$async$$2)
case 3:s=g
r=s.a
q=s.c
if(q!==200||r==null)throw A.h(A.cW("Failed to load terms content from "+e+". Status: "+A.j(q)))
if(r.length>2097152)throw A.h(A.cW("Terms content from "+e+" exceeds the size limit."))
v=r
x=1
break
case 1:return A.q(v,w)}})
return A.r($async$$2,w)},
$S:221};(function installTearOffs(){var x=a.installInstanceTearOff,w=a._instance_0u
x(B.Ya.prototype,"ghu",0,0,function(){return[null]},["$1","$0"],["a9V","b3"],1,0,0)
var v
w(v=B.S4.prototype,"ga5k","aHB",0)
w(v,"gaHC","aHD",0)
w(v,"garh","z5",2)})();(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.i,[B.Ya,B.Ct])
w(B.tV,A.wJ)
w(B.S4,A.tC)
x(A.wD,[B.b2V,B.b2W,B.b2Z])
x(A.mN,[B.b2X,B.bfl])
x(A.wE,[B.b2Y,B.bg7])})()
A.bat(b.typeUniverse,JSON.parse('{"Ct":{"bpx":[]},"tV":{"X":[],"f":[]},"S4":{"a_":["tV"]}}'))
var y=(function rtii(){var x=A.a5
return{o:x("wj"),F:x("je"),p:x("b3<c>"),D:x("P<u>"),l:x("bpx"),u:x("y<f>"),w:x("c"),B:x("bh<dT>"),q:x("af<dT>"),v:x("~")}})();(function constants(){D.a20=new A.b0(15e6)
D.a2T=new A.ai(24,12,24,24)
D.a2U=new A.ai(24,16,24,120)
D.af8={Accept:0}
D.ae7=new A.Q(D.af8,["text/markdown, text/plain"],A.a5("Q<c,c>"))})();(function lazyInitializers(){var x=a.lazyFinal
x($,"c10","bBh",()=>A.dG(new B.bfl(),null,!1,null,null,y.l))
x($,"c1s","bBp",()=>{var w=y.w
return C.dN.Bp(new B.bg7(),w,w)})})()};
(a=>{a["Mb0l9eJ/V2yEMiNsvfjGyB+ZRGs="]=a.current})($__dart_deferred_initializers__);