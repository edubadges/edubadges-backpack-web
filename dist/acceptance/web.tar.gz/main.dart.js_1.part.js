((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={Xg:function Xg(d){this.a=d
this.c=this.b=null},C4:function C4(d){this.a=d},
bBY(d){return new B.tv(d,null)},
tv:function tv(d,e){this.d=d
this.a=e},
Rl:function Rl(d){var _=this
_.w=d
_.x=!1
_.d=$
_.c=_.a=null},
b1d:function b1d(d){this.a=d},
b1e:function b1e(d){this.a=d},
b1f:function b1f(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
b1h:function b1h(d){this.a=d},
b1g:function b1g(){},
bcB:function bcB(){},
bdj:function bdj(){}},D
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[3],B)
D=c[8]
B.Xg.prototype={
gGv(){return this.b},
gadZ(){return this.b!=null},
gKf(){return this.a.a},
a8M(d){var x,w=this,v=null,u=w.a
if((u.a.a&30)!==0){u=w.b
if(!J.d(d,u==null?v:u.d)){u=w.b
A.j(u==null?v:u.d)
A.j(d)
u=w.b
A.j(u==null?v:u.e)
A.dE().j(0)
A.dE()}return}x=w.c
if(x==null)x=A.boC(v,v,v,v,v,v,v,v,v,v,v,v,v,"",v,v,v,v,v,v,v,v,v,v,v)
x=A.th(d,"The request was manually cancelled by the user.",x,v,A.dE(),C.kU)
w.b=x
u.cL(x)},
b4(){return this.a8M(null)}}
B.C4.prototype={
FM(){var x=0,w=A.t(y.v),v=1,u=[],t=this,s,r,q,p,o,n
var $async$FM=A.o(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:v=3
x=6
return A.n(t.a.l6("/accept-general-terms",y.v),$async$FM)
case 6:s=e
if(s.c!==200){p=A.cY("Failed to accept general terms")
throw A.h(p)}v=1
x=5
break
case 3:v=2
n=u.pop()
r=A.Z(n)
q=A.ac(n)
$.d4().kO("Error accepting general terms",r,q)
throw n
x=5
break
case 2:x=1
break
case 5:return A.q(null,w)
case 1:return A.p(u.at(-1),w)}})
return A.r($async$FM,w)},
$ibmn:1}
B.tv.prototype={
ag(){return new B.Rl(A.kc(null,null))}}
B.Rl.prototype={
aA(){this.aY()
this.w.a4(this.ga4g())},
m(){var x=this.w
x.N(this.ga4g())
x.m()
this.aB()},
aFS(){var x=this,w=x.w.f,v=C.b.gbB(w).at
v.toString
w=C.b.gbB(w).Q
w.toString
if(v>=w-100){if(!x.x)x.a_(new B.b1d(x))}else if(x.x)x.a_(new B.b1e(x))},
aFU(){var x=this.w,w=C.b.gbB(x.f).Q
w.toString
x.kI(w,C.tq,C.el)},
yM(){var x=0,w=A.t(y.v),v=this,u,t
var $async$yM=A.o(function(d,e){if(d===1)return A.p(e,w)
for(;;)switch(x){case 0:t=v.gbx()
x=2
return A.n(t.cj($.bxQ(),y.l).FM(),$async$yM)
case 2:x=3
return A.n(t.au($.beF().gn6(),y.D),$async$yM)
case 3:u=e
t=v.c
if(t!=null)if(u)A.co(t).fG("/notification-permission",null)
else A.co(t).fG("/",null)
return A.q(null,w)}})
return A.r($async$yM,w)},
J(d){var x,w,v,u,t=this,s=null,r=A.aL(d,C.x,y.F)
r.toString
x=A.K(d)
w=t.gbx().cj($.bxX().$1(t.a.d),y.p)
v=t.x?r.gVu():r.gVv()
u=t.x?t.gapU():t.gaFT()
return A.en(A.jH(s,!1,s,!0,s,s,A.ah(r.gVw(),s,s,s,s,s,s,s),s),s,A.jg(A.kh(C.cf,A.b([A.fg(w,new B.b1f(t,d,x,x.ok,x.ax),new B.b1g(),new B.b1h(d),!1,!0,!1),A.Dw(0,A.dg(s,new A.yj(v,u,!1,s),C.B,A.K(d).fx,s,s,s,s,s,D.a2n,s,s,s),s,s,0,0,s,s)],y.u),C.P,C.c9,s),!0,720,t.w),s)}}
var z=a.updateTypes(["~()","~([i?])","Q<~>()","C4(b1)"])
B.b1d.prototype={
$0(){this.a.x=!0},
$S:0}
B.b1e.prototype={
$0(){this.a.x=!1},
$S:0}
B.b1f.prototype={
$1(d){var x,w,v=this,u=null
if(d.length===0){x=A.aL(v.b,C.x,y.F)
x.toString
return A.ba(A.e_(u,u,u,x.gdQ(),u,u,u,u,u,u),u,u)}x=A.bnm(v.c)
w=v.d.z
return A.nc(new A.iD(A.tX(d,u,x.aM7(w==null?u:w.aU(v.e.k3))),u),v.a.w,C.Z,D.a2o,u,u,C.ax)},
$S:1056}
B.b1h.prototype={
$0(){var x=null,w=A.aL(this.a,C.x,y.F)
w.toString
return A.ba(A.e_(x,x,x,w.gdQ(),x,x,x,x,x,x),x,x)},
$S:43}
B.b1g.prototype={
$2(d,e){return A.ba(A.nX(d,e),null,null)},
$S:47}
B.bcB.prototype={
$1(d){return new B.C4(d.cj($.mk(),y.o))},
$S:z+3}
B.bdj.prototype={
$2(d,e){return this.aiq(d,e)},
aiq(d,e){var x=0,w=A.t(y.w),v,u,t,s,r
var $async$$2=A.o(function(f,g){if(f===1)return A.p(g,w)
for(;;)switch(x){case 0:s=A.a_m(null)
r=new B.Xg(new A.be(new A.ae($.ab,y.q),y.B))
d.TU(r.gjh())
x=3
return A.n(s.aiy(e,r,y.w),$async$$2)
case 3:u=g
t=u.c
if(t===200&&u.a!=null){t=u.a
t.toString
v=t
x=1
break}throw A.h(A.cY("Failed to load terms content from "+e+". Status: "+A.j(t)))
case 1:return A.q(v,w)}})
return A.r($async$$2,w)},
$S:337};(function installTearOffs(){var x=a.installInstanceTearOff,w=a._instance_0u
x(B.Xg.prototype,"gjh",0,0,function(){return[null]},["$1","$0"],["a8M","b4"],1,0,0)
var v
w(v=B.Rl.prototype,"ga4g","aFS",0)
w(v,"gaFT","aFU",0)
w(v,"gapU","yM",2)})();(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.i,[B.Xg,B.C4])
w(B.tv,A.pw)
w(B.Rl,A.tb)
x(A.wp,[B.b1d,B.b1e,B.b1h])
x(A.mC,[B.b1f,B.bcB])
x(A.wq,[B.b1g,B.bdj])})()
A.b8j(b.typeUniverse,JSON.parse('{"C4":{"bmn":[]},"tv":{"Y":[],"f":[]},"Rl":{"a0":["tv"]}}'))
var y=(function rtii(){var x=A.a5
return{o:x("w_"),F:x("kB"),p:x("bf<c>"),D:x("Q<w>"),l:x("bmn"),u:x("y<f>"),w:x("c"),B:x("be<e6>"),q:x("ae<e6>"),v:x("~")}})();(function constants(){D.a2n=new A.ai(24,12,24,24)
D.a2o=new A.ai(24,16,24,120)})();(function lazyInitializers(){var x=a.lazyFinal
x($,"bXW","bxQ",()=>A.eb(new B.bcB(),null,!1,null,null,y.l))
x($,"bYm","bxX",()=>{var w=y.w
return C.ec.Ht(new B.bdj(),w,w)})})()};
(a=>{a["oG6h048p9MLuGUufxBCAhHIVGYU="]=a.current})($__dart_deferred_initializers__);