((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={XX:function XX(d){this.a=d
this.c=this.b=null},Cp:function Cp(d){this.a=d},
bEi(d){return new B.tT(d,null)},
tT:function tT(d,e){this.d=d
this.a=e},
RV:function RV(d){var _=this
_.w=d
_.x=!1
_.d=$
_.c=_.a=null},
b2s:function b2s(d){this.a=d},
b2t:function b2t(d){this.a=d},
b2u:function b2u(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
b2w:function b2w(d){this.a=d},
b2v:function b2v(){},
beq:function beq(){},
bfb:function bfb(){}},D
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[3],B)
D=c[8]
B.XX.prototype={
gH8(){return this.b},
gaf0(){return this.b!=null},
gKX(){return this.a.a},
a9J(d){var x,w=this,v=null,u=w.a
if((u.a.a&30)!==0){u=w.b
if(!J.d(d,u==null?v:u.d)){u=w.b
A.j(u==null?v:u.d)
A.j(d)
u=w.b
A.j(u==null?v:u.e)
A.dZ().j(0)
A.dZ()}return}x=w.c
if(x==null)x=A.biD(v,v,v,v,v,v,v,v,v,v,v,v,v,"",v,v,v,v,v,v,v,v,v,v,v)
x=A.pR(d,"The request was manually cancelled by the user.",x,v,A.dZ(),C.l4)
w.b=x
u.cT(x)},
b3(){return this.a9J(null)}}
B.Cp.prototype={
Gq(){var x=0,w=A.t(y.v),v=1,u=[],t=this,s,r,q,p,o,n
var $async$Gq=A.o(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:v=3
x=6
return A.m(t.a.lf("/accept-general-terms",y.v),$async$Gq)
case 6:s=e
if(s.c!==200){p=A.cW("Failed to accept general terms")
throw A.h(p)}v=1
x=5
break
case 3:v=2
n=u.pop()
r=A.Z(n)
q=A.aa(n)
$.cr().kb("Error accepting general terms",r,q)
throw n
x=5
break
case 2:x=1
break
case 5:return A.q(null,w)
case 1:return A.p(u.at(-1),w)}})
return A.r($async$Gq,w)},
$ibop:1}
B.tT.prototype={
ac(){return new B.RV(A.ke(null,null))}}
B.RV.prototype={
az(){this.aW()
this.w.a6(this.ga59())},
m(){var x=this.w
x.N(this.ga59())
x.m()
this.aw()},
aHf(){var x=this,w=x.w.f,v=C.b.gbD(w).at
v.toString
w=C.b.gbD(w).Q
w.toString
if(v>=w-100){if(!x.x)x.Y(new B.b2s(x))}else if(x.x)x.Y(new B.b2t(x))},
aHh(){var x=this.w,w=C.b.gbD(x.f).Q
w.toString
x.k5(w,C.ty,C.eo)},
z1(){var x=0,w=A.t(y.v),v=this,u,t
var $async$z1=A.o(function(d,e){if(d===1)return A.p(e,w)
for(;;)switch(x){case 0:t=v.gbA()
x=2
return A.m(t.bJ($.bA6(),y.l).Gq(),$async$z1)
case 2:x=3
return A.m(t.an($.bgA().glp(),y.D),$async$z1)
case 3:u=e
t=v.c
if(t!=null)if(u)A.cY(t).hc("/notification-permission",null)
else A.cY(t).hc("/",null)
return A.q(null,w)}})
return A.r($async$z1,w)},
J(d){var x,w,v,u,t=this,s=null,r=A.aI(d,C.w,y.F)
r.toString
x=A.I(d)
w=t.gbA().bJ($.bAe().$1(t.a.d),y.p)
v=t.x?r.gWa():r.gWb()
u=t.x?t.gar2():t.gaHg()
return A.eF(A.kF(s,!1,s,!0,s,s,A.ak(r.gWc(),s,s,s,s,s,s,s),s),s,A.k5(A.kl(C.ch,A.b([A.fO(w,new B.b2u(t,d,x,x.ok,x.ax),new B.b2v(),new B.b2w(d),!1,!0,!1),A.DS(0,A.dr(s,new A.uB(v,u,!1,s),C.D,A.I(d).fx,s,s,s,s,s,D.a2P,s,s,s),s,s,0,0,s,s)],y.u),C.Q,C.cb,s),!0,720,t.w),s)}}
var z=a.updateTypes(["~()","~([i?])","P<~>()","Cp(aS)"])
B.b2s.prototype={
$0(){this.a.x=!0},
$S:0}
B.b2t.prototype={
$0(){this.a.x=!1},
$S:0}
B.b2u.prototype={
$1(d){var x,w,v,u=this,t=null
if(d.length===0){x=A.aI(u.b,C.w,y.F)
x.toString
return A.bf(A.dR(t,t,t,x.gdN(),t,t,t,t,t,t),t,t)}x=A.vW(d)
w=A.bpm(u.c)
v=u.d.z
return A.nk(new A.iH(A.ui(x,t,w.aNL(v==null?t:v.aV(u.e.k3))),t),u.a.w,C.a_,D.a2Q,t,t,C.ay)},
$S:1076}
B.b2w.prototype={
$0(){var x=null,w=A.aI(this.a,C.w,y.F)
w.toString
return A.bf(A.dR(x,x,x,w.gdN(),x,x,x,x,x,x),x,x)},
$S:52}
B.b2v.prototype={
$2(d,e){return A.bf(A.lI(d,e),null,null)},
$S:60}
B.beq.prototype={
$1(d){return new B.Cp(d.bJ($.ms(),y.o))},
$S:z+3}
B.bfb.prototype={
$2(d,e){return this.aju(d,e)},
aju(d,e){var x=0,w=A.t(y.w),v,u,t,s,r,q
var $async$$2=A.o(function(f,g){if(f===1)return A.p(g,w)
for(;;)switch(x){case 0:if(A.bl0(e)!=="https")throw A.h(A.cW("Refusing to load terms content over a non-https URL."))
u=A.a01(A.aq4(D.a1X,!0,D.ae1,3,C.dT,C.w0,null))
t=new B.XX(new A.bh(new A.ae($.ac,y.q),y.B))
d.Jq(t.ghv())
x=3
return A.m(u.ajC(e,t,y.w),$async$$2)
case 3:s=g
r=s.a
q=s.c
if(q!==200||r==null)throw A.h(A.cW("Failed to load terms content from "+e+". Status: "+A.j(q)))
if(r.length>2097152)throw A.h(A.cW("Terms content from "+e+" exceeds the size limit."))
v=r
x=1
break
case 1:return A.q(v,w)}})
return A.r($async$$2,w)},
$S:338};(function installTearOffs(){var x=a.installInstanceTearOff,w=a._instance_0u
x(B.XX.prototype,"ghv",0,0,function(){return[null]},["$1","$0"],["a9J","b3"],1,0,0)
var v
w(v=B.RV.prototype,"ga59","aHf",0)
w(v,"gaHg","aHh",0)
w(v,"gar2","z1",2)})();(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.i,[B.XX,B.Cp])
w(B.tT,A.pK)
w(B.RV,A.tB)
x(A.wE,[B.b2s,B.b2t,B.b2w])
x(A.mK,[B.b2u,B.beq])
x(A.wF,[B.b2v,B.bfb])})()
A.b9U(b.typeUniverse,JSON.parse('{"Cp":{"bop":[]},"tT":{"X":[],"f":[]},"RV":{"a_":["tT"]}}'))
var y=(function rtii(){var x=A.a5
return{o:x("wg"),F:x("kG"),p:x("bc<c>"),D:x("P<v>"),l:x("bop"),u:x("y<f>"),w:x("c"),B:x("bh<dT>"),q:x("ae<dT>"),v:x("~")}})();(function constants(){D.a1X=new A.b_(15e6)
D.a2P=new A.ag(24,12,24,24)
D.a2Q=new A.ag(24,16,24,120)
D.af2={Accept:0}
D.ae1=new A.Q(D.af2,["text/markdown, text/plain"],A.a5("Q<c,c>"))})();(function lazyInitializers(){var x=a.lazyFinal
x($,"c_L","bA6",()=>A.dG(new B.beq(),null,!1,null,null,y.l))
x($,"c0c","bAe",()=>{var w=y.w
return C.dM.Bj(new B.bfb(),w,w)})})()};
(a=>{a["dgVJKuuUT/is+QtAoWwoML6fkvw="]=a.current})($__dart_deferred_initializers__);