((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={XY:function XY(d){this.a=d
this.c=this.b=null},Cs:function Cs(d){this.a=d},
bEp(d){return new B.tT(d,null)},
tT:function tT(d,e){this.d=d
this.a=e},
RW:function RW(d){var _=this
_.w=d
_.x=!1
_.d=$
_.c=_.a=null},
b2t:function b2t(d){this.a=d},
b2u:function b2u(d){this.a=d},
b2v:function b2v(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
b2x:function b2x(d){this.a=d},
b2w:function b2w(){},
ber:function ber(){},
bfc:function bfc(){}},D
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[3],B)
D=c[8]
B.XY.prototype={
gHa(){return this.b},
gaeZ(){return this.b!=null},
gKZ(){return this.a.a},
a9H(d){var x,w=this,v=null,u=w.a
if((u.a.a&30)!==0){u=w.b
if(!J.d(d,u==null?v:u.d)){u=w.b
A.j(u==null?v:u.d)
A.j(d)
u=w.b
A.j(u==null?v:u.e)
A.dZ().j(0)
A.dZ()}return}x=w.c
if(x==null)x=A.biG(v,v,v,v,v,v,v,v,v,v,v,v,v,"",v,v,v,v,v,v,v,v,v,v,v)
x=A.pS(d,"The request was manually cancelled by the user.",x,v,A.dZ(),C.l4)
w.b=x
u.cT(x)},
b3(){return this.a9H(null)}}
B.Cs.prototype={
Gs(){var x=0,w=A.t(y.v),v=1,u=[],t=this,s,r,q,p,o,n
var $async$Gs=A.o(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:v=3
x=6
return A.m(t.a.lf("/accept-general-terms",y.v),$async$Gs)
case 6:s=e
if(s.c!==200){p=A.cV("Failed to accept general terms")
throw A.h(p)}v=1
x=5
break
case 3:v=2
n=u.pop()
r=A.Z(n)
q=A.aa(n)
$.cr().kb("Error accepting general terms",r,q)
throw n
x=5
break
case 2:x=1
break
case 5:return A.q(null,w)
case 1:return A.p(u.at(-1),w)}})
return A.r($async$Gs,w)},
$ibot:1}
B.tT.prototype={
ac(){return new B.RW(A.kd(null,null))}}
B.RW.prototype={
az(){this.aW()
this.w.a6(this.ga57())},
m(){var x=this.w
x.N(this.ga57())
x.m()
this.aw()},
aHa(){var x=this,w=x.w.f,v=C.b.gbD(w).at
v.toString
w=C.b.gbD(w).Q
w.toString
if(v>=w-100){if(!x.x)x.Y(new B.b2t(x))}else if(x.x)x.Y(new B.b2u(x))},
aHc(){var x=this.w,w=C.b.gbD(x.f).Q
w.toString
x.k5(w,C.ty,C.eo)},
z2(){var x=0,w=A.t(y.v),v=this,u,t
var $async$z2=A.o(function(d,e){if(d===1)return A.p(e,w)
for(;;)switch(x){case 0:t=v.gbA()
x=2
return A.m(t.bJ($.bAb(),y.l).Gs(),$async$z2)
case 2:x=3
return A.m(t.an($.bgB().glp(),y.D),$async$z2)
case 3:u=e
t=v.c
if(t!=null)if(u)A.cY(t).hd("/notification-permission",null)
else A.cY(t).hd("/",null)
return A.q(null,w)}})
return A.r($async$z2,w)},
I(d){var x,w,v,u,t=this,s=null,r=A.aH(d,C.v,y.F)
r.toString
x=A.I(d)
w=t.gbA().bJ($.bAj().$1(t.a.d),y.p)
v=t.x?r.gWa():r.gWb()
u=t.x?t.gaqZ():t.gaHb()
return A.eF(A.kE(s,!1,s,!0,s,s,A.ao(r.gWc(),s,s,s,s,s,s,s),s),s,A.k4(A.jq(C.c4,A.b([A.fO(w,new B.b2v(t,d,x,x.ok,x.ax),new B.b2w(),new B.b2x(d),!1,!0,!1),A.yw(0,A.dM(s,new A.uB(v,u,!1,s),C.E,A.I(d).fx,s,s,s,s,s,D.a2O,s,s,s),s,s,0,0,s,s)],y.u),C.Q,C.bY,s),!0,720,t.w),s)}}
var z=a.updateTypes(["~()","~([i?])","P<~>()","Cs(aS)"])
B.b2t.prototype={
$0(){this.a.x=!0},
$S:0}
B.b2u.prototype={
$0(){this.a.x=!1},
$S:0}
B.b2v.prototype={
$1(d){var x,w,v,u=this,t=null
if(d.length===0){x=A.aH(u.b,C.v,y.F)
x.toString
return A.bf(A.dR(t,t,t,x.gdN(),t,t,t,t,t,t),t,t)}x=A.vX(d)
w=A.bpr(u.c)
v=u.d.z
return A.nk(new A.iG(A.ui(x,t,w.aNG(v==null?t:v.aS(u.e.k3))),t),u.a.w,C.a_,D.a2P,t,t,C.ax)},
$S:1077}
B.b2x.prototype={
$0(){var x=null,w=A.aH(this.a,C.v,y.F)
w.toString
return A.bf(A.dR(x,x,x,w.gdN(),x,x,x,x,x,x),x,x)},
$S:51}
B.b2w.prototype={
$2(d,e){return A.bf(A.lI(d,e),null,null)},
$S:59}
B.ber.prototype={
$1(d){return new B.Cs(d.bJ($.mt(),y.o))},
$S:z+3}
B.bfc.prototype={
$2(d,e){return this.ajr(d,e)},
ajr(d,e){var x=0,w=A.t(y.w),v,u,t,s,r,q
var $async$$2=A.o(function(f,g){if(f===1)return A.p(g,w)
for(;;)switch(x){case 0:if(A.bl3(e)!=="https")throw A.h(A.cV("Refusing to load terms content over a non-https URL."))
u=A.a01(A.aq4(D.a1W,!0,D.ae0,3,C.dT,C.w0,null))
t=new B.XY(new A.bh(new A.ae($.ac,y.q),y.B))
d.Js(t.ghv())
x=3
return A.m(u.ajz(e,t,y.w),$async$$2)
case 3:s=g
r=s.a
q=s.c
if(q!==200||r==null)throw A.h(A.cV("Failed to load terms content from "+e+". Status: "+A.j(q)))
if(r.length>2097152)throw A.h(A.cV("Terms content from "+e+" exceeds the size limit."))
v=r
x=1
break
case 1:return A.q(v,w)}})
return A.r($async$$2,w)},
$S:338};(function installTearOffs(){var x=a.installInstanceTearOff,w=a._instance_0u
x(B.XY.prototype,"ghv",0,0,function(){return[null]},["$1","$0"],["a9H","b3"],1,0,0)
var v
w(v=B.RW.prototype,"ga57","aHa",0)
w(v,"gaHb","aHc",0)
w(v,"gaqZ","z2",2)})();(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.i,[B.XY,B.Cs])
w(B.tT,A.pK)
w(B.RW,A.tB)
x(A.wF,[B.b2t,B.b2u,B.b2x])
x(A.mK,[B.b2v,B.ber])
x(A.wG,[B.b2w,B.bfc])})()
A.b9V(b.typeUniverse,JSON.parse('{"Cs":{"bot":[]},"tT":{"X":[],"f":[]},"RW":{"a_":["tT"]}}'))
var y=(function rtii(){var x=A.a5
return{o:x("wh"),F:x("kF"),p:x("bc<c>"),D:x("P<v>"),l:x("bot"),u:x("y<f>"),w:x("c"),B:x("bh<dT>"),q:x("ae<dT>"),v:x("~")}})();(function constants(){D.a1W=new A.b_(15e6)
D.a2O=new A.ah(24,12,24,24)
D.a2P=new A.ah(24,16,24,120)
D.af1={Accept:0}
D.ae0=new A.Q(D.af1,["text/markdown, text/plain"],A.a5("Q<c,c>"))})();(function lazyInitializers(){var x=a.lazyFinal
x($,"c_R","bAb",()=>A.dG(new B.ber(),null,!1,null,null,y.l))
x($,"c0i","bAj",()=>{var w=y.w
return C.dM.Bk(new B.bfc(),w,w)})})()};
(a=>{a["rl7/H08KlxkIjcDToyjmpuZhWcI="]=a.current})($__dart_deferred_initializers__);