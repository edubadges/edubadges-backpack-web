((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={Y7:function Y7(d){this.a=d
this.c=this.b=null},Cs:function Cs(d){this.a=d},
bFr(d){return new B.tT(d,null)},
tT:function tT(d,e){this.d=d
this.a=e},
S1:function S1(d){var _=this
_.w=d
_.x=!1
_.d=$
_.c=_.a=null},
b2R:function b2R(d){this.a=d},
b2S:function b2S(d){this.a=d},
b2T:function b2T(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
b2V:function b2V(){},
b2U:function b2U(){},
bfe:function bfe(){},
bg_:function bg_(){}},D
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[3],B)
D=c[8]
B.Y7.prototype={
gHf(){return this.b},
gafc(){return this.b!=null},
gL3(){return this.a.a},
a9U(d){var x,w=this,v=null,u=w.a
if((u.a.a&30)!==0){u=w.b
if(!J.d(d,u==null?v:u.d)){u=w.b
A.j(u==null?v:u.d)
A.j(d)
u=w.b
A.j(u==null?v:u.e)
A.dZ().j(0)
A.dZ()}return}x=w.c
if(x==null)x=A.bjw(v,v,v,v,v,v,v,v,v,v,v,v,v,"",v,v,v,v,v,v,v,v,v,v,v)
x=A.pT(d,"The request was manually cancelled by the user.",x,v,A.dZ(),C.la)
w.b=x
u.cT(x)},
b3(){return this.a9U(null)}}
B.Cs.prototype={
Gx(){var x=0,w=A.t(y.v),v=1,u=[],t=this,s,r,q,p,o,n
var $async$Gx=A.o(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:v=3
x=6
return A.m(t.a.le("/accept-general-terms",y.v),$async$Gx)
case 6:s=e
if(s.c!==200){p=A.cW("Failed to accept general terms")
throw A.h(p)}v=1
x=5
break
case 3:v=2
n=u.pop()
r=A.Z(n)
q=A.aa(n)
$.cq().kb("Error accepting general terms",r,q)
throw n
x=5
break
case 2:x=1
break
case 5:return A.q(null,w)
case 1:return A.p(u.at(-1),w)}})
return A.r($async$Gx,w)},
$ibpq:1}
B.tT.prototype={
a8(){return new B.S1(A.jq(null,null))}}
B.S1.prototype={
az(){this.aV()
this.w.a5(this.ga5k())},
m(){var x=this.w
x.N(this.ga5k())
x.m()
this.aw()},
aHy(){var x=this,w=x.w.f,v=C.b.gbD(w).at
v.toString
w=C.b.gbD(w).Q
w.toString
if(v>=w-100){if(!x.x)x.X(new B.b2R(x))}else if(x.x)x.X(new B.b2S(x))},
aHA(){var x=this.w,w=C.b.gbD(x.f).Q
w.toString
x.k5(w,C.tG,C.ep)},
z4(){var x=0,w=A.t(y.v),v=this,u,t
var $async$z4=A.o(function(d,e){if(d===1)return A.p(e,w)
for(;;)switch(x){case 0:t=v.gbx()
x=2
return A.m(t.bC($.bBa(),y.l).Gx(),$async$z4)
case 2:x=3
return A.m(t.an($.bhn().glp(),y.D),$async$z4)
case 3:u=e
t=v.c
if(t!=null)if(u)A.cY(t).he("/notification-permission",null)
else A.cY(t).he("/",null)
return A.q(null,w)}})
return A.r($async$z4,w)},
I(d){var x,w,v,u,t=this,s=null,r=A.b2(d,C.F,y.F)
r.toString
x=A.H(d)
w=t.gbx().bC($.bBi().$1(t.a.d),y.p)
v=t.x?r.gWi():r.gWj()
u=t.x?t.garf():t.gaHz()
return A.fC(A.kH(s,!1,s,!0,s,s,A.ao(r.gL6(),s,s,s,s,s,s,s),s),s,A.k7(A.iY(C.bP,A.b([A.fQ(w,new B.b2T(t,x,x.ok,x.ax),new B.b2U(),new B.b2V(),!1,!0,!1),A.yv(0,A.dN(s,new A.uB(v,u,!1,s),C.D,A.H(d).fx,s,s,s,s,s,D.a2T,s,s,s),s,s,0,0,s,s)],y.u),C.P,C.bM,s),!0,720,t.w),s)}}
var z=a.updateTypes(["~()","~([i?])","P<~>()","Cs(aS)"])
B.b2R.prototype={
$0(){this.a.x=!0},
$S:0}
B.b2S.prototype={
$0(){this.a.x=!1},
$S:0}
B.b2T.prototype={
$1(d){var x,w,v,u,t,s=this,r=null
if(d.length===0)return C.be
x=A.vX(d)
w=A.bqq(s.b)
v=s.c.z
u=v==null
t=u?r:v.aS(s.d.k3)
return A.nn(new A.q8(A.ui(x,r,w.aOb(u?r:v.AX(s.d.b,C.cW),t)),!1,r),s.a.w,C.Z,D.a2U,r,r,C.az)},
$S:1077}
B.b2V.prototype={
$0(){return C.be},
$S:51}
B.b2U.prototype={
$2(d,e){return A.bT(A.lJ(d,e),null,null)},
$S:55}
B.bfe.prototype={
$1(d){return new B.Cs(d.bC($.ms(),y.o))},
$S:z+3}
B.bg_.prototype={
$2(d,e){return this.ajH(d,e)},
ajH(d,e){var x=0,w=A.t(y.w),v,u,t,s,r,q
var $async$$2=A.o(function(f,g){if(f===1)return A.p(g,w)
for(;;)switch(x){case 0:if(A.blV(e)!=="https")throw A.h(A.cW("Refusing to load terms content over a non-https URL."))
u=A.a0b(A.aql(D.a20,!0,D.ae7,3,C.dU,C.w6,null))
t=new B.Y7(new A.bh(new A.af($.ac,y.q),y.B))
d.JA(t.ghu())
x=3
return A.m(u.ajP(e,t,y.w),$async$$2)
case 3:s=g
r=s.a
q=s.c
if(q!==200||r==null)throw A.h(A.cW("Failed to load terms content from "+e+". Status: "+A.j(q)))
if(r.length>2097152)throw A.h(A.cW("Terms content from "+e+" exceeds the size limit."))
v=r
x=1
break
case 1:return A.q(v,w)}})
return A.r($async$$2,w)},
$S:221};(function installTearOffs(){var x=a.installInstanceTearOff,w=a._instance_0u
x(B.Y7.prototype,"ghu",0,0,function(){return[null]},["$1","$0"],["a9U","b3"],1,0,0)
var v
w(v=B.S1.prototype,"ga5k","aHy",0)
w(v,"gaHz","aHA",0)
w(v,"garf","z4",2)})();(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.i,[B.Y7,B.Cs])
w(B.tT,A.wG)
w(B.S1,A.tA)
x(A.wA,[B.b2R,B.b2S,B.b2V])
x(A.mL,[B.b2T,B.bfe])
x(A.wB,[B.b2U,B.bg_])})()
A.bam(b.typeUniverse,JSON.parse('{"Cs":{"bpq":[]},"tT":{"X":[],"f":[]},"S1":{"a_":["tT"]}}'))
var y=(function rtii(){var x=A.a5
return{o:x("wg"),F:x("jc"),p:x("bd<c>"),D:x("P<v>"),l:x("bpq"),u:x("y<f>"),w:x("c"),B:x("bh<dT>"),q:x("af<dT>"),v:x("~")}})();(function constants(){D.a20=new A.b0(15e6)
D.a2T=new A.ai(24,12,24,24)
D.a2U=new A.ai(24,16,24,120)
D.af8={Accept:0}
D.ae7=new A.Q(D.af8,["text/markdown, text/plain"],A.a5("Q<c,c>"))})();(function lazyInitializers(){var x=a.lazyFinal
x($,"c0T","bBa",()=>A.dG(new B.bfe(),null,!1,null,null,y.l))
x($,"c1k","bBi",()=>{var w=y.w
return C.dN.Bo(new B.bg_(),w,w)})})()};
(a=>{a["hcHCQY4Frdg4VYrenw3UAt2hGn8="]=a.current})($__dart_deferred_initializers__);