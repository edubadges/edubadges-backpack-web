((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={Y7:function Y7(d){this.a=d
this.c=this.b=null},Cs:function Cs(d){this.a=d},
bFq(d){return new B.tV(d,null)},
tV:function tV(d,e){this.d=d
this.a=e},
S1:function S1(d){var _=this
_.w=d
_.x=!1
_.d=$
_.c=_.a=null},
b2K:function b2K(d){this.a=d},
b2L:function b2L(d){this.a=d},
b2M:function b2M(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
b2O:function b2O(){},
b2N:function b2N(){},
bfa:function bfa(){},
bfX:function bfX(){}},D
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[3],B)
D=c[8]
B.Y7.prototype={
gHd(){return this.b},
gaf8(){return this.b!=null},
gL2(){return this.a.a},
a9S(d){var x,w=this,v=null,u=w.a
if((u.a.a&30)!==0){u=w.b
if(!J.d(d,u==null?v:u.d)){u=w.b
A.j(u==null?v:u.d)
A.j(d)
u=w.b
A.j(u==null?v:u.e)
A.dZ().j(0)
A.dZ()}return}x=w.c
if(x==null)x=A.bjv(v,v,v,v,v,v,v,v,v,v,v,v,v,"",v,v,v,v,v,v,v,v,v,v,v)
x=A.pT(d,"The request was manually cancelled by the user.",x,v,A.dZ(),C.la)
w.b=x
u.cX(x)},
b3(){return this.a9S(null)}}
B.Cs.prototype={
Gv(){var x=0,w=A.t(y.v),v=1,u=[],t=this,s,r,q,p,o,n
var $async$Gv=A.o(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:v=3
x=6
return A.m(t.a.le("/accept-general-terms",y.v),$async$Gv)
case 6:s=e
if(s.c!==200){p=A.cW("Failed to accept general terms")
throw A.h(p)}v=1
x=5
break
case 3:v=2
n=u.pop()
r=A.Z(n)
q=A.aa(n)
$.co().kb("Error accepting general terms",r,q)
throw n
x=5
break
case 2:x=1
break
case 5:return A.q(null,w)
case 1:return A.p(u.at(-1),w)}})
return A.r($async$Gv,w)},
$ibpn:1}
B.tV.prototype={
a8(){return new B.S1(A.js(null,null))}}
B.S1.prototype={
az(){this.aU()
this.w.a5(this.ga5i())},
m(){var x=this.w
x.N(this.ga5i())
x.m()
this.aw()},
aHy(){var x=this,w=x.w.f,v=C.b.gbD(w).at
v.toString
w=C.b.gbD(w).Q
w.toString
if(v>=w-100){if(!x.x)x.X(new B.b2K(x))}else if(x.x)x.X(new B.b2L(x))},
aHA(){var x=this.w,w=C.b.gbD(x.f).Q
w.toString
x.k5(w,C.tH,C.ep)},
z4(){var x=0,w=A.t(y.v),v=this,u,t
var $async$z4=A.o(function(d,e){if(d===1)return A.p(e,w)
for(;;)switch(x){case 0:t=v.gbu()
x=2
return A.m(t.bA($.bB8(),y.l).Gv(),$async$z4)
case 2:t.uC($.WS())
x=3
return A.m(t.an($.bhl().glp(),y.D),$async$z4)
case 3:u=e
t=v.c
if(t!=null)if(u)A.d1(t).hm("/notification-permission",null)
else A.d1(t).hm("/",null)
return A.q(null,w)}})
return A.r($async$z4,w)},
I(d){var x,w,v,u,t=this,s=null,r=A.b1(d,C.D,y.F)
r.toString
x=A.H(d)
w=t.gbu().bA($.bBg().$1(t.a.d),y.p)
v=t.x?r.gWi():r.gWj()
u=t.x?t.gard():t.gaHz()
return A.fD(A.kJ(s,!1,s,!0,!1,s,s,A.aG(s,s,A.an(r.gL5(),s,s,s,s,s,s,s),!1,s,s,!1,!1,s,s,s,1,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,C.p,s),s),s,A.k8(A.iZ(C.bP,A.b([A.fR(w,new B.b2M(t,x,x.ok,x.ax),new B.b2N(),new B.b2O(),!1,!0,!1),A.yw(0,A.dO(s,new A.uE(v,u,!1,s),C.E,A.H(d).fx,s,s,s,s,s,D.a2U,s,s,s),s,s,0,0,s,s)],y.u),C.P,C.bM,s),!0,720,t.w),s)}}
var z=a.updateTypes(["~()","~([i?])","P<~>()","Cs(aS)"])
B.b2K.prototype={
$0(){this.a.x=!0},
$S:0}
B.b2L.prototype={
$0(){this.a.x=!1},
$S:0}
B.b2M.prototype={
$1(d){var x,w,v,u,t,s=this,r=null
if(d.length===0)return C.be
x=A.vZ(d)
w=A.bqn(s.b)
v=s.c.z
u=v==null
t=u?r:v.aS(s.d.k3)
return A.m6(new A.q8(A.uk(x,r,w.aOc(u?r:v.AX(s.d.b,C.cW),t)),!1,r),s.a.w,C.Z,D.a2V,r,r,C.at)},
$S:1081}
B.b2O.prototype={
$0(){return C.be},
$S:51}
B.b2N.prototype={
$2(d,e){return A.bT(A.lM(d,e),null,null)},
$S:55}
B.bfa.prototype={
$1(d){return new B.Cs(d.bA($.mt(),y.o))},
$S:z+3}
B.bfX.prototype={
$2(d,e){return this.ajF(d,e)},
ajF(d,e){var x=0,w=A.t(y.w),v,u,t,s,r,q
var $async$$2=A.o(function(f,g){if(f===1)return A.p(g,w)
for(;;)switch(x){case 0:if(A.blU(e)!=="https")throw A.h(A.cW("Refusing to load terms content over a non-https URL."))
u=A.a0b(A.aql(D.a21,!0,D.ae9,3,C.dU,C.w5,null))
t=new B.Y7(new A.bi(new A.ah($.ac,y.q),y.B))
d.Jz(t.ghu())
x=3
return A.m(u.ajN(e,t,y.w),$async$$2)
case 3:s=g
r=s.a
q=s.c
if(q!==200||r==null)throw A.h(A.cW("Failed to load terms content from "+e+". Status: "+A.j(q)))
if(r.length>2097152)throw A.h(A.cW("Terms content from "+e+" exceeds the size limit."))
v=r
x=1
break
case 1:return A.q(v,w)}})
return A.r($async$$2,w)},
$S:216};(function installTearOffs(){var x=a.installInstanceTearOff,w=a._instance_0u
x(B.Y7.prototype,"ghu",0,0,function(){return[null]},["$1","$0"],["a9S","b3"],1,0,0)
var v
w(v=B.S1.prototype,"ga5i","aHy",0)
w(v,"gaHz","aHA",0)
w(v,"gard","z4",2)})();(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.i,[B.Y7,B.Cs])
w(B.tV,A.wH)
w(B.S1,A.tC)
x(A.wB,[B.b2K,B.b2L,B.b2O])
x(A.mL,[B.b2M,B.bfa])
x(A.wC,[B.b2N,B.bfX])})()
A.bai(b.typeUniverse,JSON.parse('{"Cs":{"bpn":[]},"tV":{"X":[],"f":[]},"S1":{"a_":["tV"]}}'))
var y=(function rtii(){var x=A.a5
return{o:x("wh"),F:x("je"),p:x("b3<c>"),D:x("P<v>"),l:x("bpn"),u:x("y<f>"),w:x("c"),B:x("bi<dT>"),q:x("ah<dT>"),v:x("~")}})();(function constants(){D.a21=new A.b0(15e6)
D.a2U=new A.ai(24,12,24,24)
D.a2V=new A.ai(24,16,24,120)
D.afa={Accept:0}
D.ae9=new A.Q(D.afa,["text/markdown, text/plain"],A.a5("Q<c,c>"))})();(function lazyInitializers(){var x=a.lazyFinal
x($,"c0S","bB8",()=>A.dG(new B.bfa(),null,!1,null,null,y.l))
x($,"c1j","bBg",()=>{var w=y.w
return C.dN.Bo(new B.bfX(),w,w)})})()};
(a=>{a["zwg36CiJgb5Cz/q04eaNt2tMcR8="]=a.current})($__dart_deferred_initializers__);