((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={Y7:function Y7(d){this.a=d
this.c=this.b=null},Ct:function Ct(d){this.a=d},
bFt(d){return new B.tT(d,null)},
tT:function tT(d,e){this.d=d
this.a=e},
S1:function S1(d){var _=this
_.w=d
_.x=!1
_.d=$
_.c=_.a=null},
b2R:function b2R(d){this.a=d},
b2S:function b2S(d){this.a=d},
b2T:function b2T(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
b2V:function b2V(){},
b2U:function b2U(){},
bfe:function bfe(){},
bg_:function bg_(){}},D
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[3],B)
D=c[8]
B.Y7.prototype={
gHf(){return this.b},
gafd(){return this.b!=null},
gL4(){return this.a.a},
a9V(d){var x,w=this,v=null,u=w.a
if((u.a.a&30)!==0){u=w.b
if(!J.d(d,u==null?v:u.d)){u=w.b
A.j(u==null?v:u.d)
A.j(d)
u=w.b
A.j(u==null?v:u.e)
A.dZ().j(0)
A.dZ()}return}x=w.c
if(x==null)x=A.bjy(v,v,v,v,v,v,v,v,v,v,v,v,v,"",v,v,v,v,v,v,v,v,v,v,v)
x=A.pT(d,"The request was manually cancelled by the user.",x,v,A.dZ(),C.la)
w.b=x
u.cT(x)},
b3(){return this.a9V(null)}}
B.Ct.prototype={
Gx(){var x=0,w=A.t(y.v),v=1,u=[],t=this,s,r,q,p,o,n
var $async$Gx=A.o(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:v=3
x=6
return A.m(t.a.le("/accept-general-terms",y.v),$async$Gx)
case 6:s=e
if(s.c!==200){p=A.cW("Failed to accept general terms")
throw A.h(p)}v=1
x=5
break
case 3:v=2
n=u.pop()
r=A.Z(n)
q=A.aa(n)
$.cq().kb("Error accepting general terms",r,q)
throw n
x=5
break
case 2:x=1
break
case 5:return A.q(null,w)
case 1:return A.p(u.at(-1),w)}})
return A.r($async$Gx,w)},
$ibpr:1}
B.tT.prototype={
a8(){return new B.S1(A.jq(null,null))}}
B.S1.prototype={
az(){this.aV()
this.w.a5(this.ga5k())},
m(){var x=this.w
x.N(this.ga5k())
x.m()
this.aw()},
aHA(){var x=this,w=x.w.f,v=C.b.gbD(w).at
v.toString
w=C.b.gbD(w).Q
w.toString
if(v>=w-100){if(!x.x)x.X(new B.b2R(x))}else if(x.x)x.X(new B.b2S(x))},
aHC(){var x=this.w,w=C.b.gbD(x.f).Q
w.toString
x.k5(w,C.tG,C.ep)},
z4(){var x=0,w=A.t(y.v),v=this,u,t
var $async$z4=A.o(function(d,e){if(d===1)return A.p(e,w)
for(;;)switch(x){case 0:t=v.gbx()
x=2
return A.m(t.bC($.bBb(),y.l).Gx(),$async$z4)
case 2:x=3
return A.m(t.an($.bho().glp(),y.D),$async$z4)
case 3:u=e
t=v.c
if(t!=null)if(u)A.cY(t).he("/notification-permission",null)
else A.cY(t).he("/",null)
return A.q(null,w)}})
return A.r($async$z4,w)},
I(d){var x,w,v,u,t=this,s=null,r=A.b1(d,C.D,y.F)
r.toString
x=A.H(d)
w=t.gbx().bC($.bBj().$1(t.a.d),y.p)
v=t.x?r.gWi():r.gWj()
u=t.x?t.garg():t.gaHB()
return A.fC(A.kH(s,!1,s,!0,!1,s,s,A.aG(s,s,A.an(r.gL7(),s,s,s,s,s,s,s),!1,s,s,!1,!1,s,s,s,1,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,C.p,s),s),s,A.k7(A.iY(C.bP,A.b([A.fQ(w,new B.b2T(t,x,x.ok,x.ax),new B.b2U(),new B.b2V(),!1,!0,!1),A.yw(0,A.dN(s,new A.uC(v,u,!1,s),C.E,A.H(d).fx,s,s,s,s,s,D.a2T,s,s,s),s,s,0,0,s,s)],y.u),C.P,C.bM,s),!0,720,t.w),s)}}
var z=a.updateTypes(["~()","~([i?])","P<~>()","Ct(aS)"])
B.b2R.prototype={
$0(){this.a.x=!0},
$S:0}
B.b2S.prototype={
$0(){this.a.x=!1},
$S:0}
B.b2T.prototype={
$1(d){var x,w,v,u,t,s=this,r=null
if(d.length===0)return C.be
x=A.vY(d)
w=A.bqr(s.b)
v=s.c.z
u=v==null
t=u?r:v.aS(s.d.k3)
return A.nn(new A.q8(A.ui(x,r,w.aOd(u?r:v.AX(s.d.b,C.cW),t)),!1,r),s.a.w,C.Z,D.a2U,r,r,C.az)},
$S:1078}
B.b2V.prototype={
$0(){return C.be},
$S:50}
B.b2U.prototype={
$2(d,e){return A.bQ(A.lJ(d,e),null,null)},
$S:55}
B.bfe.prototype={
$1(d){return new B.Ct(d.bC($.ms(),y.o))},
$S:z+3}
B.bg_.prototype={
$2(d,e){return this.ajI(d,e)},
ajI(d,e){var x=0,w=A.t(y.w),v,u,t,s,r,q
var $async$$2=A.o(function(f,g){if(f===1)return A.p(g,w)
for(;;)switch(x){case 0:if(A.blX(e)!=="https")throw A.h(A.cW("Refusing to load terms content over a non-https URL."))
u=A.a0b(A.aqm(D.a20,!0,D.ae7,3,C.dU,C.w6,null))
t=new B.Y7(new A.bh(new A.af($.ac,y.q),y.B))
d.JB(t.ghu())
x=3
return A.m(u.ajQ(e,t,y.w),$async$$2)
case 3:s=g
r=s.a
q=s.c
if(q!==200||r==null)throw A.h(A.cW("Failed to load terms content from "+e+". Status: "+A.j(q)))
if(r.length>2097152)throw A.h(A.cW("Terms content from "+e+" exceeds the size limit."))
v=r
x=1
break
case 1:return A.q(v,w)}})
return A.r($async$$2,w)},
$S:259};(function installTearOffs(){var x=a.installInstanceTearOff,w=a._instance_0u
x(B.Y7.prototype,"ghu",0,0,function(){return[null]},["$1","$0"],["a9V","b3"],1,0,0)
var v
w(v=B.S1.prototype,"ga5k","aHA",0)
w(v,"gaHB","aHC",0)
w(v,"garg","z4",2)})();(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.i,[B.Y7,B.Ct])
w(B.tT,A.wH)
w(B.S1,A.tA)
x(A.wB,[B.b2R,B.b2S,B.b2V])
x(A.mL,[B.b2T,B.bfe])
x(A.wC,[B.b2U,B.bg_])})()
A.bam(b.typeUniverse,JSON.parse('{"Ct":{"bpr":[]},"tT":{"X":[],"f":[]},"S1":{"a_":["tT"]}}'))
var y=(function rtii(){var x=A.a5
return{o:x("wh"),F:x("jc"),p:x("bb<c>"),D:x("P<v>"),l:x("bpr"),u:x("y<f>"),w:x("c"),B:x("bh<dT>"),q:x("af<dT>"),v:x("~")}})();(function constants(){D.a20=new A.b0(15e6)
D.a2T=new A.ai(24,12,24,24)
D.a2U=new A.ai(24,16,24,120)
D.af8={Accept:0}
D.ae7=new A.Q(D.af8,["text/markdown, text/plain"],A.a5("Q<c,c>"))})();(function lazyInitializers(){var x=a.lazyFinal
x($,"c0V","bBb",()=>A.dG(new B.bfe(),null,!1,null,null,y.l))
x($,"c1m","bBj",()=>{var w=y.w
return C.dN.Bo(new B.bg_(),w,w)})})()};
(a=>{a["cpzYiIbA++Osm5ta9YjxOu8WMr4="]=a.current})($__dart_deferred_initializers__);