((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
aIf(d,e,f){return new B.uE(d,f,e,null)},
uE:function uE(d,e,f,g){var _=this
_.d=d
_.e=e
_.f=f
_.a=g},
Ta:function Ta(d){var _=this
_.w=d
_.d=$
_.c=_.a=null},
b60:function b60(d){this.a=d},
b61:function b61(d,e){this.a=d
this.b=e},
b6_:function b6_(){},
b63:function b63(){},
b62:function b62(){}},D
A=c[0]
C=c[2]
B=a.updateHolder(c[4],B)
D=c[7]
B.uE.prototype={
a8(){return new B.Ta(A.jq(null,null))}}
B.Ta.prototype={
m(){this.w.m()
this.aw()},
aFY(d){var x=d.ay,w=d.CW,v=A.b([],y.h)
if(x!=null&&x.length!==0)v.push(x)
if(w!=null&&w.length!==0)v.push(w)
if(v.length===0)return null
return C.b.b5(v,"\n\n")},
aFX(){var x,w=this,v=w.a
if(v.f){v=w.c
v.toString
A.iO(v,!1).dT()}else{v=w.c
v.toString
v=A.cY(v).c
v===$&&A.a()
v=v.k6()
x=w.c
if(v){x.toString
A.cY(x).jF(null)}else{x.toString
A.cY(x).he("/catalog",null)}}},
I(d){var x,w,v,u,t,s,r,q,p,o,n=this,m=null,l=A.b2(d,C.F,y.p)
l.toString
x=A.H(d).ax
w=n.gbx()
v=$.nW()
u=n.a
t=w.bC(v.$1(new A.mD(u.e,u.d)),y.a)
u=A.AP(t,y.k)
if(u==null)s=m
else{w=u.b.a
s=w==null?m:w.b.ch}w=n.a.f?m:new A.wh(n.ga4f(),"/",m)
v=A.ao(l.gxR(),m,m,m,m,m,m,m)
u=x.p4
r=u==null
q=r?x.k2:u
p=r?x.k2:u
o=A.b([],y.e)
if(n.a.f)o.push(A.ik(m,m,A.eR(C.dV,x.b,m,m),m,m,n.ga4f(),m,m,l.gt5()))
if(s!=null&&s.length!==0)o.push(A.ik(m,m,A.eR(D.AE,x.k3,m,m),m,m,new B.b60(s),m,m,l.gLz()))
l=A.kH(o,!1,q,m,w,p,v,m)
w=r?x.k2:u
return A.fC(l,w,A.k7(A.fQ(t,new B.b61(n,d),new B.b62(),new B.b63(),!1,!0,!1),!0,720,n.w),m)}}
var z=a.updateTypes(["~()"])
B.b60.prototype={
$0(){return A.Ar(this.a)},
$S:0}
B.b61.prototype={
$1(d){var x=null,w=d==null?x:d.b,v=w!=null?this.a.aFY(w):x,u=v==null?x:C.c.b6(v)
if(u==null)u=""
if(u.length===0)return C.yM
return A.nn(new A.q8(A.ui(A.vX(u),new B.b6_(),A.wi(this.b)),!1,x),this.a.w,C.Z,C.zU,x,x,C.az)},
$S:1085}
B.b6_.prototype={
$3(d,e,f){if(e==null)return
A.Ar(e)},
$S:1086}
B.b63.prototype={
$0(){return C.be},
$S:51}
B.b62.prototype={
$2(d,e){return A.bT(A.lJ(d,e),null,null)},
$S:55};(function installTearOffs(){var x=a._instance_0u
x(B.Ta.prototype,"ga4f","aFX",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.uE,A.wG)
x(B.Ta,A.tA)
w(A.wA,[B.b60,B.b63])
w(A.mL,[B.b61,B.b6_])
x(B.b62,A.wB)})()
A.bam(b.typeUniverse,JSON.parse('{"uE":{"X":[],"f":[]},"Ta":{"a_":["uE"]}}'))
var y={p:A.a5("jc"),a:A.a5("bd<h5?>"),h:A.a5("y<c>"),e:A.a5("y<f>"),k:A.a5("h5?")};(function constants(){D.AE=new A.fx(58220,"MaterialIcons",null,!0)})()};
(a=>{a["TW9yRF8PJRiB2COvNx160UpMXk0="]=a.current})($__dart_deferred_initializers__);