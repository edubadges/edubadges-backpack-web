((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
aHZ(d,e,f){return new B.uE(d,f,e,null)},
uE:function uE(d,e,f,g){var _=this
_.d=d
_.e=e
_.f=f
_.a=g},
T3:function T3(d){var _=this
_.w=d
_.d=$
_.c=_.a=null},
b5z:function b5z(d){this.a=d},
b5A:function b5A(d,e){this.a=d
this.b=e},
b5y:function b5y(){},
b5C:function b5C(d){this.a=d},
b5B:function b5B(){}},D
A=c[0]
C=c[2]
B=a.updateHolder(c[4],B)
D=c[7]
B.uE.prototype={
ac(){return new B.T3(A.kd(null,null))}}
B.T3.prototype={
m(){this.w.m()
this.aw()},
aFD(d){var x=d.ay,w=d.CW,v=A.b([],y.h)
if(x!=null&&x.length!==0)v.push(x)
if(w!=null&&w.length!==0)v.push(w)
if(v.length===0)return null
return C.b.b5(v,"\n\n")},
aFC(){var x,w=this,v=w.a
if(v.f){v=w.c
v.toString
A.iN(v,!1).dU()}else{v=w.c
v.toString
v=A.cY(v).c
v===$&&A.a()
v=v.k6()
x=w.c
if(v){x.toString
A.cY(x).jF(null)}else{x.toString
A.cY(x).hd("/catalog",null)}}},
I(d){var x,w,v,u,t,s,r,q,p,o,n=this,m=null,l=A.aH(d,C.v,y.p)
l.toString
x=A.I(d).ax
w=n.gbA()
v=$.pk()
u=n.a
t=w.bJ(v.$1(new A.nW(u.e,u.d)),y.a)
u=A.AP(t,y.k)
if(u==null)s=m
else{w=u.b.a
s=w==null?m:w.b.ch}w=n.a.f?m:new A.wi(n.ga44(),"/",m)
v=A.ao(l.gV4(),m,m,m,m,m,m,m)
u=x.p4
r=u==null
q=r?x.k2:u
p=r?x.k2:u
o=A.b([],y.e)
if(n.a.f)o.push(A.ie(m,m,A.f7(C.dU,x.b,m,m),m,m,n.ga44(),m,m,l.gt6()))
if(s!=null&&s.length!==0)o.push(A.ie(m,m,A.f7(D.Az,x.k3,m,m),m,m,new B.b5z(s),m,m,m))
w=A.kE(o,!1,q,m,w,p,v,m)
v=r?x.k2:u
return A.eF(w,v,A.k4(A.fO(t,new B.b5A(n,d),new B.b5B(),new B.b5C(l),!1,!0,!1),!0,720,n.w),m)}}
var z=a.updateTypes(["~()"])
B.b5z.prototype={
$0(){return A.Aq(this.a)},
$S:0}
B.b5A.prototype={
$1(d){var x=null,w=d==null?x:d.b,v=w!=null?this.a.aFD(w):x,u=v==null?x:C.c.b7(v)
if(u==null)u=""
if(u.length===0)return C.yE
return A.nk(new A.iG(A.ui(A.vX(u),new B.b5y(),A.wj(this.b)),x),this.a.w,C.a_,C.zP,x,x,C.ax)},
$S:1085}
B.b5y.prototype={
$3(d,e,f){if(e==null)return
A.Aq(e)},
$S:1086}
B.b5C.prototype={
$0(){var x=null
return A.bf(A.dR(x,x,x,this.a.gdN(),x,x,x,x,x,x),x,x)},
$S:51}
B.b5B.prototype={
$2(d,e){return A.bf(A.lI(d,e),null,null)},
$S:59};(function installTearOffs(){var x=a._instance_0u
x(B.T3.prototype,"ga44","aFC",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.uE,A.pK)
x(B.T3,A.tB)
w(A.wF,[B.b5z,B.b5C])
w(A.mK,[B.b5A,B.b5y])
x(B.b5B,A.wG)})()
A.b9V(b.typeUniverse,JSON.parse('{"uE":{"X":[],"f":[]},"T3":{"a_":["uE"]}}'))
var y={p:A.a5("kF"),a:A.a5("bc<h4?>"),h:A.a5("y<c>"),e:A.a5("y<f>"),k:A.a5("h4?")};(function constants(){D.Az=new A.fu(58220,"MaterialIcons",null,!0)})()};
(a=>{a["wN2aW3XwsQYeevnHg9uTI4jmwrY="]=a.current})($__dart_deferred_initializers__);