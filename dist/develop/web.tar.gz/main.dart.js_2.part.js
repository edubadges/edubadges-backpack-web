((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
aId(d,e,f){return new B.uH(d,f,e,null)},
uH:function uH(d,e,f,g){var _=this
_.d=d
_.e=e
_.f=f
_.a=g},
Ta:function Ta(d){var _=this
_.w=d
_.d=$
_.c=_.a=null},
b5X:function b5X(d){this.a=d},
b5Y:function b5Y(d,e){this.a=d
this.b=e},
b5W:function b5W(){},
b6_:function b6_(){},
b5Z:function b5Z(){}},D
A=c[0]
C=c[2]
B=a.updateHolder(c[4],B)
D=c[7]
B.uH.prototype={
a8(){return new B.Ta(A.js(null,null))}}
B.Ta.prototype={
m(){this.w.m()
this.aw()},
aFY(d){var x=d.ay,w=d.CW,v=A.b([],y.h)
if(x!=null&&x.length!==0)v.push(x)
if(w!=null&&w.length!==0)v.push(w)
if(v.length===0)return null
return C.b.b6(v,"\n\n")},
aFX(){var x,w=this,v=w.a
if(v.f){v=w.c
v.toString
A.iP(v,!1).dS()}else{v=w.c
v.toString
v=A.d1(v).c
v===$&&A.a()
v=v.k6()
x=w.c
if(v){x.toString
A.d1(x).jF(null)}else{x.toString
A.d1(x).hm("/catalog",null)}}},
I(d){var x,w,v,u,t,s,r,q,p,o,n=this,m=null,l=A.b1(d,C.D,y.p)
l.toString
x=A.H(d).ax
w=n.gbu()
v=$.nV()
u=n.a
t=w.bA(v.$1(new A.mD(u.e,u.d)),y.a)
u=A.ps(t,y.k)
if(u==null)s=m
else{w=u.b.a
s=w==null?m:w.b.ch}w=n.a.f
v=w?m:new A.wj(n.ga4d(),"/",m)
w=w?m:1
w=A.aG(m,m,A.an(l.gxR(),m,m,m,m,m,m,m),!1,m,m,!1,!1,m,m,m,w,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,m,C.p,m)
u=x.p4
r=u==null
q=r?x.k2:u
p=r?x.k2:u
o=A.b([],y.e)
if(n.a.f)o.push(A.ik(m,m,A.eQ(C.dV,x.b,m,m),m,m,n.ga4d(),m,m,l.gt2()))
if(s!=null&&s.length!==0)o.push(A.ik(m,m,A.eQ(D.AD,x.k3,m,m),m,m,new B.b5X(s),m,m,l.gLA()))
l=A.kJ(o,!1,q,m,!1,v,p,w,m)
w=r?x.k2:u
return A.fD(l,w,A.k8(A.fR(t,new B.b5Y(n,d),new B.b5Z(),new B.b6_(),!1,!0,!1),!0,720,n.w),m)}}
var z=a.updateTypes(["~()"])
B.b5X.prototype={
$0(){return A.As(this.a)},
$S:0}
B.b5Y.prototype={
$1(d){var x=null,w=d==null?x:d.b,v=w!=null?this.a.aFY(w):x,u=v==null?x:C.c.b5(v)
if(u==null)u=""
if(u.length===0)return C.yL
return A.m6(new A.q8(A.uk(A.w_(u),new B.b5W(),A.wk(this.b)),!1,x),this.a.w,C.Z,C.zT,x,x,C.at)},
$S:1089}
B.b5W.prototype={
$3(d,e,f){if(e==null)return
A.As(e)},
$S:1090}
B.b6_.prototype={
$0(){return C.be},
$S:51}
B.b5Z.prototype={
$2(d,e){return A.bT(A.lM(d,e),null,null)},
$S:55};(function installTearOffs(){var x=a._instance_0u
x(B.Ta.prototype,"ga4d","aFX",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.uH,A.wI)
x(B.Ta,A.tC)
w(A.wC,[B.b5X,B.b6_])
w(A.mL,[B.b5Y,B.b5W])
x(B.b5Z,A.wD)})()
A.bai(b.typeUniverse,JSON.parse('{"uH":{"X":[],"f":[]},"Ta":{"a_":["uH"]}}'))
var y={p:A.a5("je"),a:A.a5("b3<h6?>"),h:A.a5("y<c>"),e:A.a5("y<f>"),k:A.a5("h6?")};(function constants(){D.AD=new A.fy(58220,"MaterialIcons",null,!0)})()};
(a=>{a["plum4X5VQv0KDjwJv4XSZRJvZSo="]=a.current})($__dart_deferred_initializers__);